package com.example.doubletapshot

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity(), SensorEventListener {

    private lateinit var status: TextView
    private lateinit var meter: TextView
    private lateinit var sensLabel: TextView
    private var sens = 70
    private var peak = 0f
    private var singles = 0
    private var doubles = 0
    private var n = 0
    private var sm: SensorManager? = null

    private val detector = TapDetector(
        onSingle = { singles++ },
        onDouble = { doubles++ }
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        sens = prefs.getInt("sens", 70)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }

        root.addView(TextView(this).apply {
            text = "لقطة شاشة بالنقر مرتين على الظهر"
            textSize = 22f
            gravity = Gravity.CENTER
        })

        status = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(16))
        }
        root.addView(status)

        root.addView(button("1) تفعيل الخدمة (إمكانية الوصول)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("2) استثناء التطبيق من توفير البطارية") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        sensLabel = TextView(this).apply {
            textSize = 16f
            setPadding(0, dp(24), 0, dp(8))
        }
        root.addView(sensLabel)

        val bar = SeekBar(this).apply {
            max = 100
            progress = sens
        }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                sens = p
                prefs.edit().putInt("sens", p).apply()
                updateSensLabel()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(bar)
        updateSensLabel()

        root.addView(TextView(this).apply {
            text = "اختبار الحساسية (يعمل والتطبيق مفتوح):"
            textSize = 16f
            setPadding(0, dp(24), 0, dp(8))
        })
        meter = TextView(this).apply { textSize = 15f }
        root.addView(meter)
        root.addView(button("تصفير العدادات") {
            peak = 0f; singles = 0; doubles = 0
        })

        root.addView(TextView(this).apply {
            text = "انقر على ظهر الجوال وهو بيدك. إذا زاد عدّاد \"النقرات\" بدون ما يزيد \"المزدوجة\" فانقر أسرع. وإذا ما زاد شي ارفع الحساسية. إذا زادت وأنت ما تنقر خفّضها."
            textSize = 14f
            setPadding(0, dp(16), 0, 0)
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun updateSensLabel() {
        sensLabel.text = "الحساسية: $sens%  (العتبة ${"%.1f".format(TapDetector.threshold(sens))})"
    }

    override fun onResume() {
        super.onResume()
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )?.contains(packageName) == true
        status.text = if (enabled) "✅ الخدمة مفعّلة" else "❌ الخدمة غير مفعّلة"
        sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sm?.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onPause() {
        sm?.unregisterListener(this)
        super.onPause()
    }

    override fun onSensorChanged(e: SensorEvent) {
        detector.feed(e.values, e.timestamp, TapDetector.threshold(sens))
        if (detector.level > peak) peak = detector.level
        if (++n % 4 == 0) {
            meter.text = "القوة الآن: ${"%.1f".format(detector.level)}\n" +
                "أعلى قوة: ${"%.1f".format(peak)}\n" +
                "النقرات: $singles\n" +
                "النقرات المزدوجة: $doubles"
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { onClick() }
    }
}
