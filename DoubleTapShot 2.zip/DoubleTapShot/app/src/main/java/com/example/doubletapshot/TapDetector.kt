package com.example.doubletapshot

import kotlin.math.sqrt

class TapDetector(
    private val onSingle: () -> Unit = {},
    private val onDouble: () -> Unit
) {
    private val prev = FloatArray(3)
    private var hasPrev = false
    var level = 0f
        private set
    private var lastSpikeMs = 0L
    private var lastTapMs = 0L

    fun feed(v: FloatArray, tsNanos: Long, threshold: Float) {
        if (!hasPrev) {
            for (i in 0..2) prev[i] = v[i]
            hasPrev = true
            return
        }
        val dx = v[0] - prev[0]
        val dy = v[1] - prev[1]
        val dz = v[2] - prev[2]
        for (i in 0..2) prev[i] = v[i]
        level = sqrt(dx * dx + dy * dy + dz * dz)

        val now = tsNanos / 1_000_000L
        if (level > threshold && now - lastSpikeMs > 120) {
            lastSpikeMs = now
            val gap = now - lastTapMs
            if (lastTapMs != 0L && gap in 150..700) {
                lastTapMs = 0L
                onDouble()
            } else {
                lastTapMs = now
                onSingle()
            }
        }
    }

    companion object {
        fun threshold(sens: Int): Float = 14f - sens * 0.12f
    }
}
