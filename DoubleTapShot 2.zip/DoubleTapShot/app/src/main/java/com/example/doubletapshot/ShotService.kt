package com.example.doubletapshot

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.accessibility.AccessibilityEvent

class ShotService : AccessibilityService(), SensorEventListener {

    private var sm: SensorManager? = null
    private var lastShot = 0L

    private val detector = TapDetector(onDouble = {
        val now = SystemClock.elapsedRealtime()
        if (now - lastShot > 1500) {
            lastShot = now
            buzz()
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        }
    })

    override fun onServiceConnected() {
        super.onServiceConnected()
        sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sm?.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        val sens = getSharedPreferences("cfg", MODE_PRIVATE).getInt("sens", 70)
        detector.feed(e.values, e.timestamp, TapDetector.threshold(sens))
    }

    @Suppress("DEPRECATION")
    private fun buzz() {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        v.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onDestroy() {
        sm?.unregisterListener(this)
        super.onDestroy()
    }
}
