package com.example.doubletapshot

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.accessibility.AccessibilityEvent
import kotlin.math.sqrt

class ShotService : AccessibilityService(), SensorEventListener {

    private var sm: SensorManager? = null
    private val gravity = FloatArray(3)
    private var lastSpikeMs = 0L
    private var lastTapMs = 0L
    private var lastShotMs = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sm?.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        val a = 0.8f
        for (i in 0..2) gravity[i] = a * gravity[i] + (1 - a) * e.values[i]
        val x = e.values[0] - gravity[0]
        val y = e.values[1] - gravity[1]
        val z = e.values[2] - gravity[2]
        val mag = sqrt(x * x + y * y + z * z)

        val sens = getSharedPreferences("cfg", MODE_PRIVATE).getInt("sens", 70)
        val threshold = 20f - sens * 0.15f

        val now = e.timestamp / 1_000_000L
        if (mag > threshold && now - lastSpikeMs > 120) {
            lastSpikeMs = now
            onTap(now)
        }
    }

    private fun onTap(now: Long) {
        val gap = now - lastTapMs
        if (lastTapMs != 0L && gap in 150..600) {
            lastTapMs = 0L
            if (now - lastShotMs > 1500) {
                lastShotMs = now
                buzz()
                performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            }
        } else {
            lastTapMs = now
        }
    }

    @Suppress("DEPRECATION")
    private fun buzz() {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        v.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onDestroy() {
        sm?.unregisterListener(this)
        super.onDestroy()
    }
}
