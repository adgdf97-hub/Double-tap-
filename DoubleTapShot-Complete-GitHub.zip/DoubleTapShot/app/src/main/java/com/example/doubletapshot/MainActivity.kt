package com.example.doubletapshot

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }

        root.addView(TextView(this).apply {
            text = "لقطة شاشة بالنقر مرتين على الظهر"
            textSize = 22f
            gravity = Gravity.CENTER
        })

        status = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(16))
        }
        root.addView(status)

        root.addView(button("1) تفعيل الخدمة (إمكانية الوصول)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        root.addView(button("2) استثناء التطبيق من توفير البطارية") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        val sensLabel = TextView(this).apply {
            textSize = 16f
            setPadding(0, dp(24), 0, dp(8))
        }
        root.addView(sensLabel)

        val bar = SeekBar(this).apply {
            max = 100
            progress = prefs.getInt("sens", 70)
        }
        sensLabel.text = "الحساسية: ${bar.progress}%"
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                prefs.edit().putInt("sens", p).apply()
                sensLabel.text = "الحساسية: $p%"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(bar)

        root.addView(TextView(this).apply {
            text = "نصيحة: ارفع الحساسية إذا ما التقط النقرتين، وخفضها إذا التقط من الحركة العادية. انقر بإصبعك على ظهر الجوال نقرتين سريعتين."
            textSize = 14f
            setPadding(0, dp(16), 0, 0)
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )?.contains(packageName) == true
        status.text = if (enabled) "✅ الخدمة مفعّلة" else "❌ الخدمة غير مفعّلة"
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { onClick() }
    }
}
