# Double Tap Shot

An Android app that listens for two quick accelerometer taps and requests a screenshot through an enabled Accessibility Service.

## Build with GitHub Actions

The `Android APK` workflow builds a debug APK on every push to `main`, and can also be started manually.

1. Open the repository's **Actions** tab.
2. Select **Android APK**.
3. Open the latest successful run.
4. Download the `DoubleTapShot-debug-apk` artifact and extract `app-debug.apk`.

## Setup on the phone

1. Install the APK.
2. Open **Double Tap Shot**.
3. Enable its Accessibility Service in Android Accessibility settings.
4. Return to the app and adjust sensitivity.
5. Try two quick taps on the back of the phone.

## Notes

- Requires Android 9 (API 28) or newer.
- The project uses Kotlin/Android APIs only and contains no native libraries, so it does not require a separate `armeabi-v7a` or `arm64-v8a` build.
- Detection depends on the phone's accelerometer and may need sensitivity tuning. Accidental triggers are possible.
- Accessibility access is used to request Android's screenshot action. Review the permission screen before enabling it.
